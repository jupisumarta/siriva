(function($) {
    "use strict"

    new dlabSettings({
        sidebarStyle: "full", 
    });


})(jQuery);