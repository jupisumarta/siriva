(function($) {
    "use strict"

    new dlabSettings({
        direction: "rtl"
    });


})(jQuery);