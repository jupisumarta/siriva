<?php

namespace App\Http\Controllers;

// use App\Models\User;
use App\Models\Siriva;
use App\Models\SirivaPekerjaan;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PemeriksaanController extends Controller
{
    function index(){
        $data['list_pasien'] = Siriva::all();
        return view('siriva.pemeriksaan.index',$data);
    }


    function cek(Siriva $pasien){
        $data['pasien'] = $pasien;
        return view('siriva.pemeriksaan.cek',$data);
    }

    function create(){
         $data['list_pekerjaan'] = SirivaPekerjaan::all();
        return view('siriva.pemeriksaan.create',$data);
    }

    function store(){
        $kirim = new Siriva;
       $kirim->siriva_status_wa = 1;
       $kirim->siriva_rm = mt_rand(111111,999999);
       $kirim->siriva_tanggal_periksa = date('Y-m-d');
       $kirim->siriva_nama_pasien = request('siriva_nama_pasien');
       $kirim->siriva_suku_pasien = request('siriva_suku_pasien');
       $kirim->siriva_alamat_pasien = request('siriva_alamat_pasien');
       $kirim->siriva_kel_pasien = request('siriva_kel_pasien');
       $kirim->siriva_suami_pasien = request('siriva_suami_pasien');
       $kirim->siriva_berat = request('siriva_berat');
       $kirim->siriva_tinggi = request('siriva_tinggi');
       $kirim->siriva_telp = request('siriva_telp');
       $kirim->siriva_kawin_pasien = request('siriva_kawin_pasien');
       $kirim->siriva_kawin_suami = request('siriva_kawin_suami');
       $kirim->siriva_pendidikan = request('siriva_pendidikan');
       $kirim->siriva_pekerjaan_pasien = request('siriva_pekerjaan_pasien');
       $kirim->siriva_pekerjaan_suami = request('siriva_pekerjaan_suami');
       $kirim->siriva_usia_haid = request('siriva_usia_haid');
       $kirim->siriva_usia_kawin = request('siriva_usia_kawin');
       $kirim->siriva_usia_hamil = request('siriva_usia_hamil');
       $kirim->siriva_hpht = request('siriva_hpht');
       $kirim->siriva_manopause = request('siriva_manopause');
       $kirim->siriva_manopause_umur = request('siriva_manopause_umur');
       $kirim->siriva_siklus_haid = request('siriva_siklus_haid');
       $kirim->siriva_jumlah_melahirkan = request('siriva_jumlah_melahirkan');
       $kirim->siriva_menyusui = request('siriva_menyusui');
       $kirim->siriva_caesar = request('siriva_caesar');
       $kirim->siriva_keguguran = request('siriva_keguguran');
       $kirim->siriva_keluarga_kanker = request('siriva_keluarga_kanker');
       $kirim->siriva_siapa = request('siriva_siapa');
       $kirim->siriva_kanker = request('siriva_kanker');
       $kirim->siriva_kanker_nama = request('siriva_kanker_nama');
       $kirim->siriva_cairan = request('siriva_cairan');
       $kirim->siriva_nyeri = request('siriva_nyeri');
       $kirim->siriva_nyeri = request('siriva_nyeri');
       $kirim->siriva_darah_luar = request('siriva_darah_luar');
       $kirim->siriva_benjolan = request('siriva_benjolan');
       $kirim->siriva_nyeri_payudara = request('siriva_nyeri_payudara');
       $kirim->siriva_cairan_abnormal = request('siriva_cairan_abnormal');
       $kirim->siriva_hpht = request('siriva_hpht');
       $kirim->siriva_lain = request('siriva_lain');
       $kirim->save();
       return back()->with('success','Data berhasil terkirim');
   }
}
