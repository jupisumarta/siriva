<h1>Silahkan Ke <a href="http://localhost:8000/logout">http://localhost:8000/logout</a> untuk ke halaman logout</h1>
<br>
<br>
<br>
<br>
<br>
{{-- <div class="card card-body">
    <form action="{{ url('/') }}" method="post">
        @csrf
        <div class="form-group">
            <label for="" class="control-label">username</label>
            <input type="text" class="form-control" name="user_username">
        </div>
        <div class="form-group">
            <label for="" class="control-label">Password</label>
            <input type="password" class="form-control" name="user_password">
        </div>
        <button class="btn btn-warning float-end mt-3"><i class="bx bx-save"> Save</i></button>
    </form>
</div> --}}

