<div class="dlabnav">
    <div class="dlabnav-scroll">

        <ul class="metismenu" id="menu">
            <li><a class="" href="<?php echo e(url('/')); ?>" aria-expanded="false">
                    <i class="fa flaticon-025-dashboard"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li><a class="" href="<?php echo e(url('pemeriksaan')); ?>" aria-expanded="false">
                    <i class="fa flaticon-093-waving"></i>
                    <span class="nav-text">Pemeriksaan</span>
                </a>
            </li>
            <li><a class="" href="<?php echo e(url('pasien')); ?>" aria-expanded="false">
                    <i class="fa flaticon-050-info"></i>
                    <span class="nav-text">Pasien</span>
                </a>
            </li>


        </ul>
        <div class="plus-box">
            <p class="fs-14 font-w600 mb-2">SIRIVA <br>memudahkan<br>Pengawasan,<br>Pemeriksaan<br>IVA</p>
            <p>Untuk Ketapang lebih baik dan lebih sehat</p>
            <img src="<?php echo e(url('public')); ?>/assets/images/SIRIVA-LOGO KECIL.png" width="100%">
        </div>
        <div class="copyright">
            <h3><strong style="font-size: 25px;" class="text-danger">SIRIVA © 2024</strong></h3>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\siriva\system\resources\views/siriva/layout/sidebar.blade.php ENDPATH**/ ?>