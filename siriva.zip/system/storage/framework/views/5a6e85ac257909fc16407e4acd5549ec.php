
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<div class="row">
		<div class="col-xl-12 col-xxl-12">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title">Pemeriksaan</h4>
				</div>
				<div class="card-body">
					<div id="smartwizard" class="form-wizard order-create">
						<ul class="nav nav-wizard">
							<li><a class="nav-link" href="#dataPasien"> 
								<span>1</span> 
							</a></li>
							<li><a class="nav-link" href="#dataPasien2">
								<span>2</span>
							</a></li>
							<li><a class="nav-link" href="#wizard_Details">
								<span>3</span>
							</a></li>
							<li><a class="nav-link" href="#cekKanker">
								<span>4</span>
							</a></li>
						</ul>
						<div class="tab-content">
							<form action="<?php echo e(url('pemeriksaan/create')); ?>" method="post">
								<?php echo csrf_field(); ?>
						
							<div id="dataPasien" class="tab-pane" role="tabpanel">
								<div class="row">
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Nama Pasien*</label>
											<input type="text" required name="siriva_nama_pasien" class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Suku Pasien*</label>
											<span>Suku Bangsa</span>
											<input type="text" name="siriva_suku_pasien" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Alamat Pasien*</label>
											<input type="text" name="siriva_alamat_pasien" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Kelurahan / Desa Pasien*</label>
											<input type="text" required name="siriva_kel_pasien" class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Nama Suami*</label>
											<input type="text" name="siriva_suami_pasien" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Berat Badan Pasien* KG</label>
											<input type="number" name="siriva_berat" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Tinggi Badan Pasien* cm</label>
											<input type="number" name="siriva_tinggi" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Telp / WA Pasien*</label>
											<input type="text" name="siriva_telp" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Status Kawin Pasien*</label>
											<select name="siriva_kawin_pasien" id="" class="form-control">
												<option value="1">Kawin</option>
												<option value="2">Belum Kawin</option>
												<option value="3">Janda</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Status Kawin Suami*</label>
											<select name="siriva_kawin_suami" id="" class="form-control">
												<option value="1">Kawin</option>
												<option value="2">Belum Kawin</option>
												<option value="3">Janda</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Pendidikan Pasien*</label>
											<select name="siriva_pendidikan" id="" class="form-control">
												<option value="Tidak Sekolah">Tidak Sekolah</option>
												<option value="SD">SD</option>
												<option value="SMP">SMP</option>
												<option value="SMA">SMA</option>
												<option value="D III">D III (DIII)</option>
												<option value="D IV">D IV (DIII)</option>
												<option value="S1">S1</option>
												<option value="S2">S2</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Pekerjaan Pasien*</label>
											<select name="siriva_pekerjaan_pasien" id="" class="form-control">
												<option value="" hidden>-- Pilih Pekerjaan --</option>
												<?php $__currentLoopData = $list_pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($item->pekerjaan_id); ?>"><?php echo e(ucwords($item->pekerjaan_nama)); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>

									<div class="col-lg-12 mb-3">
										<div class="mb-3">
											<label class="text-label form-label">Pendidikan Suami*</label>
											<select name="siriva_pendidikan_suami" id="" class="form-control">
												<option value="Tidak Sekolah">Tidak Sekolah</option>
												<option value="SD">SD</option>
												<option value="SMP">SMP</option>
												<option value="SMA">SMA</option>
												<option value="D III">D III (DIII)</option>
												<option value="D IV">D IV (DIII)</option>
												<option value="S1">S1</option>
												<option value="S2">S2</option>
											</select>
										</div>
									</div>
									
								</div>
							</div>
							<div id="dataPasien2" class="tab-pane" role="tabpanel">
								<div class="row">
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Usia Pertama Haid*</label>
											<input type="number" name="siriva_usia_haid" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Usia Pertama Kawin*</label>
											<input type="number" name="siriva_usia_kawin" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Usia Pertama Hamil*</label>
											<input type="number" name="siriva_usia_hamil" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">HPHT*</label>
											<input type="text" name="siriva_hpht" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Manopause*</label>
											<input type="number" name="" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Umur Manopause*</label>
											<input type="number" name="siriva_manopause" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Siklus Haid*</label>
											<select name="siriva_siklus_haid" id="" class="form-control">
												<option value="1">Teratur</option>
												<option value="0">Tidak Teratur</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Jumlah Melahirkan*</label>
											<input type="number" name="siriva_jumlah_melahirkan" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Pernah Menyusui*</label>
											<select name="siriva_menyusui" id="" class="form-control">
												<option value="1">Ya</option>
												<option value="0">Tidak</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Caesar*</label>
											<select name="siriva_caesar" id="" class="form-control">
												<option value="1">Ya</option>
												<option value="0">Tidak</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Keguguran*</label>
											<select name="siriva_keguguran" id="" class="form-control">
												<option value="1">Ya</option>
												<option value="0">Tidak</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Keluarga Sakit Kanker*</label>
											<select name="siriva_keluarga_kanker" id="" class="form-control">
												<option value="1">Ya</option>
												<option value="0">Tidak</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Siapa yang sakit*</label>
											<input type="text" name="siriva_siapa" required class="form-control">
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Kanker apa?*</label>
											<input type="text" name="siriva_kanker" class="form-control" >
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Keluar banyak cairan / keputihan*</label>
											<select name="siriva_cairan" id="" class="form-control">
												<option value="1">Ya</option>
												<option value="0">Tidak</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Nyeri diperut bagian bawah*</label>
											<select name="siriva_nyeri" id="" class="form-control">
												<option value="1">Ya</option>
												<option value="0">Tidak</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Pendarahan bila bersenggama*</label>
											<select name="siriva_darah" id="" class="form-control">
												<option value="1">Ya</option>
												<option value="0">Tidak</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Pendarahan diluar haid*</label>
											<select name="siriva_darah_luar" id="" class="form-control">
												<option value="1">Ya</option>
												<option value="0">Tidak</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Benjolan Payudara / Ketiak*</label>
											<select name="siriva_benjolan" id="" class="form-control">
												<option value="1">Ya</option>
												<option value="0">Tidak</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Nyeri payudara*</label>
											<select name="siriva_nyeri_payudara" id="" class="form-control">
												<option value="1">Ya</option>
												<option value="0">Tidak</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Keluar cairan abnormal dari puting payudara*</label>
											<select name="siriva_cairan_abnormal" id="" class="form-control">
												<option value="1">Ya</option>
												<option value="0">Tidak</option>
											</select>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Lain*</label>
											<input type="text" name="siriva_lain" class="form-control" required>
										</div>
									</div>


								</div>
							</div>

							<!-- belum -->
							<div id="wizard_Details" class="tab-pane" role="tabpanel">
								<div class="row">
									<div class="col-sm-4 mb-2">
										<h4>Curiga Kanker*</h4>
									</div>
									<div class="col-6 col-sm-4 mb-2">
										<div class="mb-3">
											<input class="form-control" value="9.00" type="number" name="input1" id="input1">
										</div>
									</div>
									<div class="col-6 col-sm-4 mb-2">
										<div class="mb-3">
											<input class="form-control" value="6.00" type="number" name="input2" id="input2">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-4 mb-2">
										<h4>SSK*</h4>
									</div>
									<div class="col-6 col-sm-4 mb-2">
										<div class="mb-3">
											<input class="form-control" value="9.00" type="number" name="input3" id="input3">
										</div>
									</div>
									<div class="col-6 col-sm-4 mb-2">
										<div class="mb-3">
											<input class="form-control" value="6.00" type="number" name="input4" id="input4">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-4 mb-2">
										<h4>PAP Smear*</h4>
									</div>
									<div class="col-6 col-sm-4 mb-2">
										<div class="mb-3">
											<input class="form-control" value="9.00" type="number" name="input5" id="input5">
										</div>
									</div>
									<div class="col-6 col-sm-4 mb-2">
										<div class="mb-3">
											<input class="form-control" value="6.00" type="number" name="input6" id="input6">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-4 mb-2">
										<h4>Hasil IVA*</h4>
									</div>
									<div class="col-6 col-sm-4 mb-2">
										<div class="mb-3">
											<input class="form-control" value="9.00" type="number" name="input7" id="input7">
										</div>
									</div>
									<div class="col-6 col-sm-4 mb-2">
										<div class="mb-3">
											<input class="form-control" value="6.00" type="number" name="input8" id="input8">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-4 mb-2">
										<h4>IVA Lainnya*</h4>
									</div>
									<div class="col-6 col-sm-4 mb-2">
										<div class="mb-3">
											<input class="form-control" value="9.00" type="number" name="input9" id="input9">
										</div>
									</div>
									<div class="col-6 col-sm-4 mb-2">
										<div class="mb-3">
											<input class="form-control" value="6.00" type="number" name="input10" id="input10">
										</div>
									</div>
								</div>
								
								
							</div>
							<div id="cekKanker" class="tab-pane" role="tabpanel">
								<div class="row">
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Menggunakan Probekrio Tip*</label>
											<input type="text" name="firstName" class="form-control" placeholder="Cellophane Square" required>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Antibiotik Profiaksis 7 hari*</label>
											<input type="email" class="form-control" id="emial1" placeholder="example@example.com.com" required>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Menjelaskan kemungkinan keadaan*</label>
											<input type="text" name="phoneNumber" class="form-control" placeholder="(+1)408-657-9007" required>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Hasil Pemeriksaan Payudara - Kiri*</label>
											<input type="text" name="place" class="form-control" required>
										</div>
									</div>
									<div class="col-lg-6 mb-2">
										<div class="mb-3">
											<label class="text-label form-label">Hasil Pemeriksaan Payudara - Kanan*</label>
											<input type="text" name="place" class="form-control" required>
										</div>
									</div>

									<div class="col-md-12">
										<button class="btn btn-primary btn-block">PROSES</button>
									</div>
									
								</div>
							</div>
								</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('siriva.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siriva\system\resources\views/siriva/pemeriksaan/create.blade.php ENDPATH**/ ?>