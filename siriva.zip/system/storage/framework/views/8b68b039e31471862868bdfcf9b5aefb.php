<div class="footer">
    <div class="copyright">
        <p>Designed &amp; Developed by <a href="https://ketapangkab.go.id/" target="_blank">PDE-DISKOMINFO</a> 2024
        </p>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\siriva\system\resources\views/siriva/layout/footer.blade.php ENDPATH**/ ?>