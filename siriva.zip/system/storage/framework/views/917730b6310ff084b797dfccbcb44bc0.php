<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="SIRIVA" />
    <meta property="og:title" content="SIRIVA" />
    <meta property="og:description" content="SIRIVA" />
    <meta property="og:image" content="https://jobick.dexignlab.com/xhtml/social-image.png" />
    <meta name="format-detection" content="telephone=no">

    <!-- PAGE TITLE HERE -->
    <title>SIRIVA</title>

    <!-- FAVICONS ICON -->
    <link rel="shortcut icon" type="image/png" href="<?php echo e(url('public')); ?>/assets/images/favicon.png" />
    <link href="<?php echo e(url('public')); ?>/assets/vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
    <link href="<?php echo e(url('public')); ?>/assets/vendor/owl-carousel/owl.carousel.css" rel="stylesheet">

    <!-- Form step -->
    <link href="<?php echo e(url('public')); ?>/assets/vendor/jquery-smartwizard/dist/css/smart_wizard.min.css" rel="stylesheet">

    <!-- Style css -->
    <link href="<?php echo e(url('public')); ?>/assets/css/style.css" rel="stylesheet">
    <script src="<?php echo e(url('public')); ?>/assets/jquery-3.6.1.min.js"></script>


</head>

<body>


    <!--*******************
    	Preloader start
	********************-->
    <div id="preloader">
        <div class="lds-ripple">
            <div></div>
            <div></div>
        </div>
    </div>
    <!--*******************
    	Preloader end
	********************-->

    <!--**********************************
        	Main wrapper start
	***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            	Header start
		***********************************-->
		<?php echo $__env->make('siriva.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--**********************************
        		Header end ti-comment-alt
		***********************************-->


		<!--**********************************
            	Sidebar start
		***********************************-->
		<?php echo $__env->make('siriva.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--**********************************
            	Sidebar end
		***********************************-->


		<!--**********************************
            	Content body start
        ***********************************-->
		<div class="content-body">
			<?php echo $__env->yieldContent('content'); ?>
		</div>

    </div>
    <!--**********************************
            Content body end
    ***********************************-->

	<!--**********************************
			Footer start
	***********************************-->
	<?php echo $__env->make('siriva.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--**********************************
			Footer end
	***********************************-->

    <!--**********************************
        	Main wrapper end
	***********************************-->

    <!-- Required vendors -->
    <script src="<?php echo e(url('public')); ?>/assets/vendor/global/global.min.js"></script>

    <script src="<?php echo e(url('public')); ?>/assets/vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>

    <!-- Dashboard 1 -->
    <script src="<?php echo e(url('public')); ?>/assets/js/dashboard/dashboard-1.js"></script>

    <script src="<?php echo e(url('public')); ?>/assets/js/custom.min.js"></script>
    <script src="<?php echo e(url('public')); ?>/assets/js/dlabnav-init.js"></script>
    
	<!-- Form Steps -->
	<script src="<?php echo e(url('public')); ?>/assets/vendor/jquery-smartwizard/dist/js/jquery.smartWizard.js"></script>
	<script src="<?php echo e(url('public')); ?>/assets/vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>
	
    
	<script>
		$(document).ready(function(){
			// SmartWizard initialize
			$('#smartwizard').smartWizard(); 
		});
	</script>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\siriva\system\resources\views/siriva/base.blade.php ENDPATH**/ ?>